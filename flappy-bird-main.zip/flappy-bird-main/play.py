# Importarea librăriilor necesare
import pygame
import sys
from setup.constants import *  #include variabile precum WIDTH, HEIGHT, GRAVITY, FPS etc.
import random

# Inițializarea Pygame și fereastra jocului
pygame.init()
win = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Flappy Bird")

# Setarea iconiței ferestrei
gameicon = pygame.image.load('assets/scene/gameicon.png').convert_alpha()
pygame.display.set_icon(gameicon)

clock = pygame.time.Clock()

# Încărcarea și redimensionarea fundalului și podelei
background_scene = pygame.image.load('assets/scene/background.png').convert()
background_scene = pygame.transform.scale(background_scene, (WIDTH, HEIGHT))

floor_scene = pygame.image.load('assets/scene/floor.png').convert()
floor_scene = pygame.transform.scale2x(floor_scene)

# Încărcarea fontului pentru scor
game_font = pygame.font.Font('assets/fonts/flappy.ttf', 40)

# Încărcarea și scalarea sprite-urilor păsării
bird_downflap = pygame.transform.scale2x(pygame.image.load('assets/sprites/bird_down.png').convert_alpha())
bird_midflap = pygame.transform.scale2x(pygame.image.load('assets/sprites/bird_mid.png').convert_alpha())
bird_upflap = pygame.transform.scale2x(pygame.image.load('assets/sprites/bird_up.png').convert_alpha())
bird_frames = [bird_downflap, bird_midflap, bird_upflap]
bird_index = 0
bird_sprite = bird_frames[bird_index]
bird_hitbox = bird_sprite.get_rect(center=(100, 400))  # poziția de start

# Încărcarea sunetelor
flap_sound = pygame.mixer.Sound('assets/sounds/flap.ogg')
clash_sound = pygame.mixer.Sound('assets/sounds/clash.ogg')
score_sound = pygame.mixer.Sound('assets/sounds/score.ogg')

# Ecranul de Game Over
gameover_scene = pygame.image.load('assets/scene/onset.png').convert_alpha()
gameover_scene = pygame.transform.scale2x(gameover_scene)
gameover_rect = gameover_scene.get_rect(center=(262, 400))

# Configurarea obstacolelor (țevi)
pipe_sprite = pygame.image.load('assets/sprites/pipe.png').convert()
pipe_sprite = pygame.transform.scale2x(pipe_sprite)
pipe_list = []
pipe_height = [200, 400, 500]

# Eveniment pentru generarea țevilor la fiecare 1500ms
SPAWNPIPE = pygame.USEREVENT
pygame.time.set_timer(SPAWNPIPE, 1500)

# Eveniment pentru animarea păsării la fiecare 200ms
BIRD_FLAP = pygame.USEREVENT + 1
pygame.time.set_timer(BIRD_FLAP, 200)

# Funcție pentru desenarea podelei în mișcare
def draw_floor():
    win.blit(floor_scene, (DYNAMIC_FLOOR, 700))
    win.blit(floor_scene, (DYNAMIC_FLOOR + 500, 700))

# Creează o pereche nouă de țevi
def create_pipe():
    random_pipe = random.choice(pipe_height)
    bottom_pipe = pipe_sprite.get_rect(midtop=(700, random_pipe))
    top_pipe = pipe_sprite.get_rect(midbottom=(700, random_pipe - 250))
    return bottom_pipe, top_pipe

# Mișcă țevile spre stânga și returnează doar cele vizibile
def move_pipe(pipes):
    for pipe in pipes:
        pipe.centerx -= 5
    visible_pipes = [pipe for pipe in pipes if pipe.right > -50]
    return visible_pipes

# Desenează țevile pe ecran (unele inversate pentru partea de sus)
def draw_pipe(pipes):
    for pipe in pipes:
        if pipe.bottom >= 800:
            win.blit(pipe_sprite, pipe)
        else:
            flip_pipe = pygame.transform.flip(pipe_sprite, False, True)
            win.blit(flip_pipe, pipe)

# Detectează coliziunea cu țevi sau marginile ecranului
def check_collision(pipes):
    global CAN_SCORE
    for pipe in pipes:
        if bird_hitbox.colliderect(pipe):
            clash_sound.play()
            pygame.time.delay(300)
            CAN_SCORE = True
            return False
    if bird_hitbox.top <= -150 or bird_hitbox.bottom >= 700:
        clash_sound.play()
        pygame.time.delay(300)
        CAN_SCORE = True
        return False
    return True

# Rotește pasărea în funcție de viteza sa (pentru efect vizual)
def rotate_bird(bird):
    new_bird = pygame.transform.rotozoom(bird, -BIRD_VELOCITY * 3, 1)
    return new_bird

# Schimbă sprite-ul păsării pentru animare
def bird_animation():
    new_bird = bird_frames[bird_index]
    new_bird_rect = new_bird.get_rect(center=(100, bird_hitbox.centery))
    return new_bird, new_bird_rect

# Afișează scorul curent și highscore-ul (în funcție de starea jocului)
def score_display(game_active):
    if game_active == 'main_game':
        score_surface = game_font.render(str(int(SCORE)), True, WHITE)
        score_rect = score_surface.get_rect(center=(262, 100))
        win.blit(score_surface, score_rect)
    if game_active == 'game_over':
        score_surface = game_font.render(f'Score: {int(SCORE)}', True, WHITE)
        score_rect = score_surface.get_rect(center=(262, 100))
        win.blit(score_surface, score_rect)

        HIGHSCORE_surface = game_font.render(f'High Score: {int(HIGH_SCORE)}', True, WHITE)
        HIGHSCORE_rect = score_surface.get_rect(center=(200, 685))
        win.blit(HIGHSCORE_surface, HIGHSCORE_rect)

# Actualizează scorul maxim dacă scorul curent e mai mare
def update_score(SCORE, HIGH_SCORE):
    if SCORE > HIGH_SCORE:
        HIGH_SCORE = SCORE
    return HIGH_SCORE

# Verifică dacă pasărea a trecut printr-o țeavă (pentru scor)
def pipe_score_check():
    global SCORE, CAN_SCORE
    if pipe_list:
        for pipe in pipe_list:
            if 95 < pipe.centerx < 105 and CAN_SCORE:
                SCORE += 1
                score_sound.play()
                CAN_SCORE = False
            if pipe.centerx < 0:
                CAN_SCORE = True

# Bucla principală a jocului
while RUN:
    # Gestionarea evenimentelor
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        # Pasărea sare dacă e apăsat SPACE
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE and GAME_ACTIVE == True:
                BIRD_VELOCITY = 0
                BIRD_VELOCITY -= 7
                flap_sound.play()

            # Reîncepe jocul dacă e terminat
            if event.key == pygame.K_SPACE and GAME_ACTIVE == False:
                GAME_ACTIVE = True
                pipe_list.clear()
                bird_hitbox.center = (100, 400)
                BIRD_VELOCITY = 0
                SCORE = 0

        # Generare obstacole la intervale regulate
        if event.type == SPAWNPIPE:
            pipe_list.extend(create_pipe())

        # Animare pasăre
        if event.type == BIRD_FLAP:
            if bird_index < 2:
                bird_index += 1
            else:
                bird_index = 0
            bird_sprite, bird_hitbox = bird_animation()

    # Desenare fundal
    win.blit(background_scene, (0, 0))

    if GAME_ACTIVE:
        # Fizica păsării
        BIRD_VELOCITY += GRAVITY
        bird_hitbox.centery += BIRD_VELOCITY
        rotated_sprite = rotate_bird(bird_sprite)
        win.blit(rotated_sprite, bird_hitbox)

        # Verificare coliziuni
        GAME_ACTIVE = check_collision(pipe_list)

        # Mișcare și desenare țevi
        pipe_list = move_pipe(pipe_list)
        draw_pipe(pipe_list)

        # Actualizare și afișare scor
        pipe_score_check()
        score_display('main_game')
    else:
        # Afișare scenă game over + scoruri
        win.blit(gameover_scene, gameover_rect)
        HIGH_SCORE = update_score(SCORE, HIGH_SCORE)
        score_display('game_over')

    # Mișcarea podelei
    DYNAMIC_FLOOR -= 1
    draw_floor()
    if DYNAMIC_FLOOR <= -500:
        DYNAMIC_FLOOR = 0

    # Actualizarea ecranului
    pygame.display.update()
    clock.tick(FPS)
